/**
 * Util methods used by Jsoup. Please don't depend on the APIs implemented here as the contents may change without
 * notice.
 */
package org.jsoup.internal;
