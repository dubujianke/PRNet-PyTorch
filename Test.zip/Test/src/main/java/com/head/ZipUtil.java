package com.head;

import java.io.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipUtil {
    public static void prs(String dstFile, String src) {
        File zipFile = new File(dstFile);
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            File file = new File(src);
            addFileToZip(file, "0.jpg", zos);
            zos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void addFileToZip(File file, String fileName, ZipOutputStream zos) throws IOException {
        try (InputStream is = new FileInputStream(file)) {
            ZipEntry zipEntry = new ZipEntry(fileName);
            zos.putNextEntry(zipEntry);
            byte[] buffer = new byte[1024];
            int length;
            while ((length = is.read(buffer)) > 0) {
                zos.write(buffer, 0, length);
            }
        }
    }
}