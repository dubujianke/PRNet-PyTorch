package com.alading.tool.stock.model;

public class MinuteEntity {
    public int v;

    public void add() {
        v++;
    }

}
