package com.alading.tool.stock;

public class ZTReason {
    public MinuteLine minuteLine;
    public String reason = "";
}
