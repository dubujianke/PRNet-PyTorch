package com.alading.tool.stock;

import java.io.IOException;

public class StragetyGroup {


    public static void main(String[] args) throws Exception {
        StragetyZTBottom.main(args);
        StragetyBottom.main(args);
    }



}
