package com.alading.tool.stock.model;

public class MA {
    int period;
    double v;
}
