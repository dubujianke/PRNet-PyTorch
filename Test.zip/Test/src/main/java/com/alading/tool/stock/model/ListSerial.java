package com.alading.tool.stock.model;

import java.io.Serializable;
import java.util.ArrayList;

public class ListSerial extends ArrayList implements Serializable {

}
