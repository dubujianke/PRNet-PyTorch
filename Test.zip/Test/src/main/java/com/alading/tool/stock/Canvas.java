package com.alading.tool.stock;

public class Canvas {
    public int width = 270;
    public int height = 370;
    public int marginLeft = 10;
    public int marginTop = 23;


}
