package com.alading.tool.stock.cyq;

//public class CYQData {
//    public double[] x;
//    public List<Double> y;
//    public float benefitPart;
//    public float avgCost;
//    public float percentChips;
//
//    public CYQData() {
//    }
//
//    /**
//     * 获取指定价格的获利比例
//     * @param {number} price 价格
//     */
//        public float getBenefitPart(double price) {
//        float below = 0;
//        for (int i = 0; i < factor; i++) {
//            double x = xdata[i].toPrecision(12) / 1;
//            if (price >= minprice + i * accuracy) {
//                below += x;
//            }
//        }
//        return totalChips == 0 ? 0 : below / totalChips;
//    };
//
//}
