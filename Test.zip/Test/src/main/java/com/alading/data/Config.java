package com.alading.data;

public class Config {
    public static final String ROOT = "D:/stock/Test/res/code/";
    public static final String ROOT2 = "D:/stock/Test/res/";
}
