package com.alading.model;

public class StockLine {
    private  long id;
    private String code;
    private String name;
//
//    v100
//            v400
//    v900
//            vl900

}
