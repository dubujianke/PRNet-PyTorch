package com.alading.util;

public class Constant {

    public static final int WEEK_MA60_PREVENT = 0;
    public static final int WEEK_STANDMA60_SHADOWUP__PREVENT = 1;
    public static final int WEEK_UPMA60_SHADOWUP__PREVENT = 2;
    public static final int WEEK_UPMA60_UP_DOWN = 3;
    public static final int PREVUPSHADOW_CURSZ = 4;
    public static final int UP_AND_HOR = 5;
    public static final int DOWN_AND_HOR = 6;
    public static final int MON_MA10FAR = 7;
    public static final int MA10HOR_MA30FAR = 8;
    public static final int MA30_PREVENT = 9;
}
